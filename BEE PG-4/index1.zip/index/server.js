const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();

app.use(cors()); // Enable CORS
app.use(express.json());

app.post("/register", (req, res) => {
    const { username, email, number, password } = req.body;

    if (!username || !email || !number || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const filePath = path.join(__dirname, "users.json");
    const userData = { username, email, number, password };

    fs.readFile(filePath, "utf8", (err, data) => {
        if (err && err.code !== "ENOENT") {
            return res.status(500).json({ message: "Failed to read user data" });
        }

        const users = data ? JSON.parse(data) : [];
        users.push(userData);

        fs.writeFile(filePath, JSON.stringify(users, null, 2), (writeErr) => {
            if (writeErr) {
                return res.status(500).json({ message: "Failed to save user data" });
            }
            res.status(200).json({ message: "Registration successful" });
        });
    });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
